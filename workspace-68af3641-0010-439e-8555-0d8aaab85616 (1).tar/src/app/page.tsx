'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { useToast } from '@/hooks/use-toast'
import { Moon, Sun, Mail, Phone, Youtube, Flower2, Sparkles, Wind, Music, Heart, Play, Pause, RotateCcw } from 'lucide-react'
import { useTheme } from 'next-themes'
import { useEffect, useRef } from 'react'

export default function Home() {
  const { theme, setTheme } = useTheme()
  const { toast } = useToast()
  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  })
  const [newsletterEmail, setNewsletterEmail] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Breathing exercise state
  const [isBreathing, setIsBreathing] = useState(false)
  const [breathPhase, setBreathPhase] = useState<'idle' | 'inhale' | 'hold' | 'exhale'>('idle')
  const [breathCycle, setBreathCycle] = useState(0)
  const breathingIntervalRef = useRef<NodeJS.Timeout | null>(null)

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // In a real deployment, this would send to your API
    // For static hosting, form is shown but data won't be sent
    alert('Thank you! In a deployed site with a backend, this would send your message. For now, please email me at jjyoga@live.com')
    setContactForm({ name: '', email: '', subject: '', message: '' })
  }

  const handleNewsletterSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // In a real deployment, this would send to your API
    // For static hosting, form is shown but data won't be sent
    alert('Thank you for subscribing! In a deployed site with a backend, this would sign you up. For now, please email me at jjyoga@live.com')
    setNewsletterEmail('')
  }

  // Breathing exercise functions
  const startBreathing = () => {
    setIsBreathing(true)
    setBreathPhase('inhale')
    setBreathCycle(1)
  }

  const stopBreathing = () => {
    setIsBreathing(false)
    setBreathPhase('idle')
    if (breathingIntervalRef.current) {
      clearInterval(breathingIntervalRef.current)
      breathingIntervalRef.current = null
    }
  }

  const resetBreathing = () => {
    stopBreathing()
    setBreathCycle(0)
  }

  useEffect(() => {
    if (isBreathing && !breathingIntervalRef.current) {
      let phase = 'inhale'
      let cycle = breathCycle

      // Breathing pattern: 4s inhale, 4s hold, 4s exhale, 4s hold
      const runBreathCycle = () => {
        // Inhale phase
        setBreathPhase('inhale')
        setTimeout(() => {
          if (!isBreathing) return

          // Hold phase
          setBreathPhase('hold')
          setTimeout(() => {
            if (!isBreathing) return

            // Exhale phase
            setBreathPhase('exhale')
            setTimeout(() => {
              if (!isBreathing) return

              // Hold phase
              setBreathPhase('hold')
              cycle++
              setBreathCycle(cycle)
            }, 4000)
          }, 4000)
        }, 4000)
      }

      runBreathCycle()
      breathingIntervalRef.current = setInterval(runBreathCycle, 16000) // 4+4+4+4 = 16s per full cycle
    }

    return () => {
      if (breathingIntervalRef.current) {
        clearInterval(breathingIntervalRef.current)
        breathingIntervalRef.current = null
      }
    }
  }, [isBreathing, breathCycle])

  const getBreathInstruction = () => {
    switch (breathPhase) {
      case 'inhale':
        return 'Breathe In'
      case 'hold':
        return 'Hold'
      case 'exhale':
        return 'Breathe Out'
      default:
        return 'Start Breathing'
    }
  }

  const getBreathScale = () => {
    switch (breathPhase) {
      case 'inhale':
        return 'scale-125'
      case 'hold':
        return 'scale-125'
      case 'exhale':
        return 'scale-100'
      default:
        return 'scale-100'
    }
  }

  const getBreathOpacity = () => {
    switch (breathPhase) {
      case 'inhale':
        return 'opacity-100'
      case 'hold':
        return 'opacity-90'
      case 'exhale':
        return 'opacity-70'
      default:
        return 'opacity-80'
    }
  }


  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-pink-50/50 to-purple-50/50 dark:from-pink-950/20 dark:to-purple-950/20">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <Flower2 className="h-8 w-8 text-pink-500" />
            <span className="text-xl font-bold bg-gradient-to-r from-pink-500 to-purple-500 bg-clip-text text-transparent">
              I am the Lotus
            </span>
          </div>
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              aria-label="Toggle theme"
            >
              <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
              <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
              <span className="sr-only">Toggle theme</span>
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container px-4 py-20 md:py-32">
        <div className="flex flex-col items-center text-center space-y-8">
          <div className="relative">
            <div className="absolute -inset-4 bg-gradient-to-r from-pink-400 to-purple-400 rounded-full blur-3xl opacity-20 animate-pulse" />
            <Flower2 className="relative h-24 w-24 md:h-32 md:w-32 text-pink-500" />
          </div>
          <div className="space-y-4 max-w-3xl">
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold bg-gradient-to-r from-pink-500 via-purple-500 to-pink-500 bg-clip-text text-transparent">
              I am the Lotus
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground">
              Licensed Mental Health Counselor • Synergist • Quantum Reiki Practitioner
            </p>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Embark on a transformative wellness journey with holistic healing approaches that nurture your mind, body, and spirit
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 pt-4">
            <Button
              size="lg"
              className="bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 text-white text-lg px-8"
              onClick={() => window.open('https://momence.com/u/JJLOTUSTHERAPY-', '_blank')}
            >
              Book a Session
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="text-lg px-8"
              onClick={() => window.open('https://care.headway.co/providers/jessica-conti?utm_source=pem&utm_medium=direct_link&utm_campaign=34824', '_blank')}
            >
              Book with Insurance
            </Button>
          </div>
        </div>
      </section>

      {/* Breathing Exercise Section */}
      <section className="container px-4 py-16 md:py-24 bg-gradient-to-b from-transparent via-pink-50/30 to-transparent dark:via-pink-950/10">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-3xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-pink-500 to-purple-500 bg-clip-text text-transparent">
            Take a Moment to Breathe 🌸
          </h2>
          <p className="text-lg text-muted-foreground mb-12">
            Follow the lotus and sync your breath. Find your inner calm.
          </p>

          <Card className="border-2 border-pink-200 dark:border-pink-800 bg-gradient-to-br from-pink-50/50 to-purple-50/50 dark:from-pink-950/30 dark:to-purple-950/30 overflow-hidden">
            <CardContent className="pt-12 pb-8 px-8">
              <div className="flex flex-col items-center gap-8">
                {/* Breathing Circle */}
                <div className="relative">
                  {/* Outer glow */}
                  <div
                    className={`absolute inset-0 rounded-full bg-gradient-to-r from-pink-400 to-purple-400 blur-3xl transition-all duration-[4000ms] ${getBreathOpacity()}`}
                  />

                  {/* Main circle */}
                  <div
                    className={`relative w-48 h-48 md:w-64 md:h-64 rounded-full bg-gradient-to-br from-pink-200 to-purple-200 dark:from-pink-900/50 dark:to-purple-900/50 flex items-center justify-center transition-all duration-[4000ms] ease-in-out ${getBreathScale()} ${getBreathOpacity()}`}
                  >
                    {/* Inner lotus */}
                    <Flower2
                      className={`w-24 h-24 md:w-32 md:h-32 text-pink-500 transition-all duration-[4000ms] ease-in-out ${getBreathScale()}`}
                    />

                    {/* Pulse effect rings */}
                    {isBreathing && (
                      <>
                        <div className="absolute inset-0 rounded-full border-2 border-pink-300 dark:border-pink-700 animate-ping" />
                        <div className="absolute inset-4 rounded-full border-2 border-purple-300 dark:border-purple-700 animate-ping delay-1000" />
                      </>
                    )}
                  </div>
                </div>

                {/* Instruction text */}
                <div className="text-center space-y-2">
                  <p className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-pink-500 to-purple-500 bg-clip-text text-transparent transition-all duration-500">
                    {getBreathInstruction()}
                  </p>
                  {isBreathing && (
                    <p className="text-sm text-muted-foreground">
                      Cycle {breathCycle}
                    </p>
                  )}
                </div>

                {/* Controls */}
                <div className="flex gap-4">
                  {!isBreathing ? (
                    <Button
                      size="lg"
                      onClick={startBreathing}
                      className="bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 text-white gap-2"
                    >
                      <Play className="h-5 w-5" />
                      Start
                    </Button>
                  ) : (
                    <Button
                      size="lg"
                      onClick={stopBreathing}
                      variant="outline"
                      className="gap-2"
                    >
                      <Pause className="h-5 w-5" />
                      Pause
                    </Button>
                  )}
                  <Button
                    size="lg"
                    onClick={resetBreathing}
                    variant="ghost"
                    className="gap-2"
                    disabled={!isBreathing && breathCycle === 0}
                  >
                    <RotateCcw className="h-5 w-5" />
                    Reset
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Breathing pattern info */}
          <div className="mt-6 text-sm text-muted-foreground">
            <p>Pattern: Breathe In (4s) • Hold (4s) • Breathe Out (4s) • Hold (4s)</p>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="container px-4 py-16 md:py-24">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-pink-500 to-purple-500 bg-clip-text text-transparent">
            Holistic Services
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Discover the perfect blend of traditional counseling and alternative healing modalities
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          <Card className="border-2 hover:border-pink-300 dark:hover:border-pink-700 transition-all duration-300 hover:shadow-lg hover:shadow-pink-500/10">
            <CardHeader>
              <div className="w-12 h-12 rounded-full bg-pink-100 dark:bg-pink-900/30 flex items-center justify-center mb-4">
                <Heart className="h-6 w-6 text-pink-500" />
              </div>
              <CardTitle className="text-xl">Mental Health Counseling</CardTitle>
              <CardDescription>
                Licensed Mental Health Counselor (LMHC) providing compassionate, evidence-based therapy for individuals seeking personal growth and healing
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-2 hover:border-purple-300 dark:hover:border-purple-700 transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/10">
            <CardHeader>
              <div className="w-12 h-12 rounded-full bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center mb-4">
                <Sparkles className="h-6 w-6 text-purple-500" />
              </div>
              <CardTitle className="text-xl">Quantum Reiki</CardTitle>
              <CardDescription>
                Harness the power of quantum energy healing combined with traditional Reiki techniques to promote deep relaxation and energetic balance
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-2 hover:border-pink-300 dark:hover:border-pink-700 transition-all duration-300 hover:shadow-lg hover:shadow-pink-500/10">
            <CardHeader>
              <div className="w-12 h-12 rounded-full bg-pink-100 dark:bg-pink-900/30 flex items-center justify-center mb-4">
                <Wind className="h-6 w-6 text-pink-500" />
              </div>
              <CardTitle className="text-xl">Yoga</CardTitle>
              <CardDescription>
                Guided yoga sessions designed to strengthen the mind-body connection, improve flexibility, and cultivate inner peace
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-2 hover:border-purple-300 dark:hover:border-purple-700 transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/10">
            <CardHeader>
              <div className="w-12 h-12 rounded-full bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center mb-4">
                <Music className="h-6 w-6 text-purple-500" />
              </div>
              <CardTitle className="text-xl">Sound Healing</CardTitle>
              <CardDescription>
                Experience the therapeutic vibrations of sound healing instruments to reduce stress, promote relaxation, and restore harmony
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-2 hover:border-pink-300 dark:hover:border-pink-700 transition-all duration-300 hover:shadow-lg hover:shadow-pink-500/10 md:col-span-2 lg:col-span-2">
            <CardHeader>
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-pink-100 to-purple-100 dark:from-pink-900/30 dark:to-purple-900/30 flex items-center justify-center mb-4">
                <Flower2 className="h-6 w-6 text-pink-500" />
              </div>
              <CardTitle className="text-xl">Synergist Approach</CardTitle>
              <CardDescription>
                A unique integration of multiple healing modalities customized to your individual needs. We combine counseling, energy work, movement, and sound for a truly transformative experience
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      </section>

      {/* Podcast Section */}
      <section className="container px-4 py-16 md:py-24 bg-gradient-to-b from-transparent via-pink-50/30 to-transparent dark:via-pink-950/10">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-pink-500 to-purple-500 bg-clip-text text-transparent">
            The Lotus Podcast
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Tune in for insights on mental health, wellness, and holistic healing
          </p>
        </div>
        <div className="max-w-2xl mx-auto">
          <div className="rounded-xl overflow-hidden shadow-2xl border-2 border-pink-200 dark:border-pink-800">
            <iframe
              data-testid="embed-iframe"
              style={{ borderRadius: "12px" }}
              src="https://open.spotify.com/embed/show/42XyWWH7IL6u9AHgPLjalX?utm_source=generator"
              width="100%"
              height="352"
              frameBorder="0"
              allowFullScreen
              allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="container px-4 py-16 md:py-24">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-pink-500 to-purple-500 bg-clip-text text-transparent">
              Get in Touch
            </h2>
            <p className="text-lg text-muted-foreground">
              Ready to start your journey? Reach out today!
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Contact Form */}
            <Card className="border-2 border-pink-200 dark:border-pink-800">
              <CardHeader>
                <CardTitle>Send a Message</CardTitle>
                <CardDescription>
                  I'd love to hear from you. Fill out the form below and I'll get back to you soon.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleContactSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name</Label>
                    <Input
                      id="name"
                      placeholder="Your name"
                      value={contactForm.name}
                      onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="your.email@example.com"
                      value={contactForm.email}
                      onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="subject">Subject</Label>
                    <Input
                      id="subject"
                      placeholder="How can I help you?"
                      value={contactForm.subject}
                      onChange={(e) => setContactForm({ ...contactForm, subject: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="message">Message</Label>
                    <Textarea
                      id="message"
                      placeholder="Tell me about your wellness journey..."
                      className="min-h-[120px]"
                      value={contactForm.message}
                      onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                      required
                    />
                  </div>
                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? 'Sending...' : 'Send Message 🌸'}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Contact Info */}
            <div className="space-y-6">
              <Card className="border-2 border-purple-200 dark:border-purple-800">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Flower2 className="h-5 w-5 text-pink-500" />
                    Contact Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <a
                    href="mailto:jjyoga@live.com"
                    className="flex items-center gap-3 p-3 rounded-lg hover:bg-pink-50 dark:hover:bg-pink-950/30 transition-colors"
                  >
                    <Mail className="h-5 w-5 text-pink-500" />
                    <div>
                      <p className="font-medium">Email</p>
                      <p className="text-sm text-muted-foreground">jjyoga@live.com</p>
                    </div>
                  </a>
                  <a
                    href="tel:+18136838197"
                    className="flex items-center gap-3 p-3 rounded-lg hover:bg-pink-50 dark:hover:bg-pink-950/30 transition-colors"
                  >
                    <Phone className="h-5 w-5 text-pink-500" />
                    <div>
                      <p className="font-medium">Phone</p>
                      <p className="text-sm text-muted-foreground">(813) 683-8197</p>
                    </div>
                  </a>
                  <a
                    href="https://www.youtube.com/@revjjlotus"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 p-3 rounded-lg hover:bg-pink-50 dark:hover:bg-pink-950/30 transition-colors"
                  >
                    <Youtube className="h-5 w-5 text-pink-500" />
                    <div>
                      <p className="font-medium">YouTube</p>
                      <p className="text-sm text-muted-foreground">Rev JJ Lotus</p>
                    </div>
                  </a>
                </CardContent>
              </Card>

              <Card className="border-2 border-pink-200 dark:border-pink-800 bg-gradient-to-br from-pink-50/50 to-purple-50/50 dark:from-pink-950/30 dark:to-purple-950/30">
                <CardHeader>
                  <CardTitle>Book Your Session</CardTitle>
                  <CardDescription>
                    Ready to start your journey? Book now!
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button
                    className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600"
                    onClick={() => window.open('https://momence.com/u/JJLOTUSTHERAPY-', '_blank')}
                  >
                    Book a Session
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => window.open('https://care.headway.co/providers/jessica-conti?utm_source=pem&utm_medium=direct_link&utm_campaign=34824', '_blank')}
                  >
                    Book with Insurance
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="container px-4 py-16 md:py-24 bg-gradient-to-b from-transparent via-purple-50/30 to-transparent dark:via-purple-950/10">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-3xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-pink-500 to-purple-500 bg-clip-text text-transparent">
            Join the Lotus Family
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            Subscribe to receive updates about workshops, classes, events, and wellness tips
          </p>
          <form onSubmit={handleNewsletterSubmit} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
            <Input
              type="email"
              placeholder="Enter your email"
              value={newsletterEmail}
              onChange={(e) => setNewsletterEmail(e.target.value)}
              required
              className="flex-1"
            />
            <Button
              type="submit"
              className="bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 whitespace-nowrap"
            >
              Subscribe 🌸
            </Button>
          </form>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto border-t bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container px-4 py-8 md:py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Flower2 className="h-6 w-6 text-pink-500" />
                <span className="text-lg font-bold bg-gradient-to-r from-pink-500 to-purple-500 bg-clip-text text-transparent">
                  I am the Lotus
                </span>
              </div>
              <p className="text-sm text-muted-foreground">
                Licensed Mental Health Counselor offering holistic healing through counseling, Quantum Reiki, Yoga, and Sound Healing in Florida.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2 text-sm">
                <li>
                  <button
                    onClick={() => window.open('https://momence.com/u/JJLOTUSTHERAPY-', '_blank')}
                    className="text-muted-foreground hover:text-pink-500 transition-colors"
                  >
                    Book a Session
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => window.open('https://care.headway.co/providers/jessica-conti?utm_source=pem&utm_medium=direct_link&utm_campaign=34824', '_blank')}
                    className="text-muted-foreground hover:text-pink-500 transition-colors"
                  >
                    Book with Insurance
                  </button>
                </li>
                <li>
                  <a
                    href="https://www.youtube.com/@revjjlotus"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-muted-foreground hover:text-pink-500 transition-colors"
                  >
                    YouTube Channel
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Contact</h3>
              <ul className="space-y-2 text-sm">
                <li className="text-muted-foreground">
                  <a href="mailto:jjyoga@live.com" className="hover:text-pink-500 transition-colors">
                    jjyoga@live.com
                  </a>
                </li>
                <li className="text-muted-foreground">
                  <a href="tel:+18136838197" className="hover:text-pink-500 transition-colors">
                    (813) 683-8197
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t pt-8 text-center text-sm text-muted-foreground">
            <p>© {new Date().getFullYear()} I am the Lotus. All rights reserved. 🌸</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

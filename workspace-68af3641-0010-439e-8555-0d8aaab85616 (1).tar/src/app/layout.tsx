import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme-provider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "I am the Lotus - Mental Health Counseling & Holistic Healing",
  description: "Licensed Mental Health Counselor in Florida offering Quantum Reiki, Yoga, Sound Healing, and Synergistic therapy. Transform your wellness journey with holistic healing approaches.",
  keywords: ["Mental Health Counselor", "Quantum Reiki", "Yoga", "Sound Healing", "Holistic Therapy", "Florida", "LMHC"],
  authors: [{ name: "Jessica Conti" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "I am the Lotus - Holistic Mental Health Counseling",
    description: "Transform your wellness journey with Quantum Reiki, Yoga, and Sound Healing in Florida",
    url: "https://iamthelotus.com",
    siteName: "I am the Lotus",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "I am the Lotus - Holistic Mental Health Counseling",
    description: "Transform your wellness journey with Quantum Reiki, Yoga, and Sound Healing in Florida",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}

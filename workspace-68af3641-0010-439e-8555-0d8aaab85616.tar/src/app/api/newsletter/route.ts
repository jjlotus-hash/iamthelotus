import { NextResponse } from 'next/server'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { email } = body

    // Validate email
    if (!email) {
      return NextResponse.json(
        { error: 'Email is required' },
        { status: 400 }
      )
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Invalid email address' },
        { status: 400 }
      )
    }

    // In a production environment, you would:
    // 1. Store the email in a database
    // 2. Subscribe to a newsletter service like Mailchimp, ConvertKit, or Resend
    // 3. Send a confirmation email

    // For now, we'll log the subscription and return success
    console.log('Newsletter Subscription:', {
      timestamp: new Date().toISOString(),
      email,
    })

    // Simulate processing time
    await new Promise((resolve) => setTimeout(resolve, 500))

    return NextResponse.json(
      { message: 'Newsletter subscription successful' },
      { status: 200 }
    )
  } catch (error) {
    console.error('Error processing newsletter subscription:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
